package fuzzy_model;

import exception.BadNumberOfParamsException;
import exception.UnknownLinguisticTypeException;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * Created by jadzia on 11.05.17.
 */
public abstract  class MembershipFunction extends UDF {
    public abstract Double countTruthValue(Double val);
    public Double evaluate(Double val){
        return countTruthValue(val);
    }
   // public Double evaluate(Double val, String params) throws BadNumberOfParamsException, UnknownLinguisticTypeException {
   //      tf = new MembershipFunctionProvider().parse(params);
   //     return tf.evaluate(val);
   // }

}
