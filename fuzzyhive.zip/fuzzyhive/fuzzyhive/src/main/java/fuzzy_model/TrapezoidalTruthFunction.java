package fuzzy_model;

/**
 * Created by jadzia on 11.05.17.
 */
public class TrapezoidalTruthFunction extends MembershipFunction{
    Double a;
    Double b;
    Double c;
    Double d;


    public TrapezoidalTruthFunction(Double a, Double b, Double c, Double d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    public Double countTruthValue(Double val) {
        if (val < a)
            return 0.0;
        else if (val <= b && val > a)
            return (val - a)/(b-a);
        else if (val > b && val <= c)
            return 1.0;
        else if (val > c && val <= d)
            return (d - val )/(d-c);
        else // val  > d
            return 0.0;
    }
}
