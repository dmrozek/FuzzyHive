package fuzzy_model;

import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * Created by jadzia on 29.05.17.
 */
public class TrapezoidMembershipFunctionFactory extends UDF {

    public TrapezoidalTruthFunction evaluate(Double a, Double b, Double c, Double d){
        return new TrapezoidalTruthFunction(a,b,c,d);
    }
}
