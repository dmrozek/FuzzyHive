package fuzzy_model;

import java.util.ArrayList;
import java.util.Arrays;

import exception.BadNumberOfParamsException;
import exception.UnknownLinguisticTypeException;
import main.LinguistiTypeEvaluator;

/**
 * Created by jadzia on 20.09.17.
 */
public class MembershipFunctionProvider {



    public MembershipFunction parse(String params) throws BadNumberOfParamsException, UnknownLinguisticTypeException {
        //MembershipFunctionEvaluator.evaluate(params);
        LinguistiTypeEvaluator evaluator = new LinguistiTypeEvaluator();


        params.replaceAll(" ","");
        String[] paramsArray = params.split("/");
        evaluator.evaluate(paramsArray);
        ArrayList tfParams =new ArrayList(Arrays.asList(paramsArray));
        String tfType = tfParams.remove(0).toString();
        Double a = (Double.parseDouble(tfParams.get(0).toString()));
        Double b = (Double.parseDouble(tfParams.get(1).toString()));
        Double c = (Double.parseDouble(tfParams.get(2).toString()));
        Double d = (Double.parseDouble(tfParams.get(3).toString()));
        return new TrapezoidalTruthFunction(a,b,c,d);
    }
}
