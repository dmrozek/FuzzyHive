package fuzzy_model;

import exception.BadNumberOfParamsException;
import exception.UnknownLinguisticTypeException;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * Created by jadzia on 11.10.17.
 */
public class GenericMembershipFunction extends UDF {

    public Double evaluate(String params, Double val) throws BadNumberOfParamsException, UnknownLinguisticTypeException {
        MembershipFunctionProvider provider = new MembershipFunctionProvider();
        MembershipFunction membershipFunction = provider.parse(params);
        return  membershipFunction.evaluate(val);
    }
}
