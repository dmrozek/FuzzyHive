package functions;

/**
 * Created by jadzia on 05.05.17.
 */
public class ToLower {
}
