package functions.bmi;

import fuzzy_model.TrapezoidalTruthFunction;

/**
 * Created by jadzia on 11.05.17.
 */
public class Obese extends TrapezoidalTruthFunction {

    public Obese() {
        super(29.0, 30.0, 100.0, 100.0);
    }
}
