package functions.bmi;

import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by jadzia on 12.05.17.
 */
public class BmiGroups extends UDF {
    public Text evaluate(Double val){


        Map< String, Double> resultMap= new HashMap< String, Double>();
        resultMap.put("Underweight", new Underweight().evaluate(val));
        resultMap.put("Normal", new Normal().evaluate(val));
        resultMap.put("Overweight", new Overweight().evaluate(val));
        resultMap.put("Obese",new Obese().evaluate(val));

        Map.Entry<String, Double> maxEntry = null;

        for (Map.Entry<String, Double> entry : resultMap.entrySet())
        {
            if (maxEntry == null || entry.getValue().compareTo(maxEntry.getValue()) > 0)
            {
                maxEntry = entry;
            }
        }
        return new Text(maxEntry.getKey());

    }
}
