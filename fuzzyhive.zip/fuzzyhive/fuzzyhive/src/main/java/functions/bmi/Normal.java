package functions.bmi;

import fuzzy_model.TrapezoidalTruthFunction;

/**
 * Created by jadzia on 11.05.17.
 */
public class Normal extends TrapezoidalTruthFunction {
    public Normal() {
        super(17.5, 18.5, 25.0 , 26.0);
    }

}
