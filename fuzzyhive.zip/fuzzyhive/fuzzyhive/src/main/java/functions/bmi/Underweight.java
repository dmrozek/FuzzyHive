package functions.bmi;

import fuzzy_model.TrapezoidalTruthFunction;

import org.apache.hadoop.hive.ql.exec.UDF;


/**
 * Created by jadzia on 10.05.17.
 */
public  class Underweight extends TrapezoidalTruthFunction{

   // TruthFunction tf = new TrapezoidalTruthFunction(0.0,0.0,18.5,19.5);

    public Underweight() {
        super(0.0, 0.0,18.5 , 19.5);
    }

}
