package functions.bmi;

import fuzzy_model.TrapezoidalTruthFunction;

/**
 * Created by jadzia on 11.05.17.
 */
public class Overweight extends TrapezoidalTruthFunction {

    public Overweight() {
        super(24.0, 25.0, 30.0, 31.0);

    }
}
