package functions; /**
 * Created by jadzia on 04.05.17.
 */


import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.io.Text;

@Description(
        name = "toupper",
        value = "_FUNC_(str) - Converts a string to uppercase",
        extended = "Example:\n" +
                "  > SELECT toupper(author_name) FROM authors a;\n" +
                "  STEPHEN KING"
)
public class ToUpper extends UDF {

    public Text evaluate(Text s) {
        Text to_value = new Text("");
        if (s == null) { return null; }
        return new Text(s.toString().toUpperCase());
    }
}
