package functions;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * Created by jadzia on 09.05.17.
 */
public class Concat  extends UDF{
    public Text evaluate(Text a, Text b){
        return new Text(a.toString().concat(b.toString()));
    }
}