package functions;

import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;

/**
 * Created by jadzia on 09.05.17.
 */
public class Bigger extends UDF {
    public boolean evaluate(Text s) {

        return s.getLength() > 6;
    }

}