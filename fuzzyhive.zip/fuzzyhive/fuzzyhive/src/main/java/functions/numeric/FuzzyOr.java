package functions.numeric;

import org.apache.hadoop.fs.shell.CommandFormat;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * Created by jadzia on 15.09.17.
 */
public class FuzzyOr extends UDF {
    /**
     * @param vals array of undefined length of values
     * @return maximum of passed values
     */
    public Double evaluate(Double... vals){
        if (vals.length < 2)
            throw new CommandFormat.NotEnoughArgumentsException(2, vals.length);

        Double max = vals[0];
        for(Double val : vals)
            if (val > max) // or -> max
                max = val;

        return max;
    }

}
