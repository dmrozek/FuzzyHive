package functions.numeric;

import fuzzy_model.TrapezoidalTruthFunction;
import org.apache.hadoop.hive.ql.exec.UDF;

import static java.lang.Math.abs;

/**
 * Created by jadzia on 29.05.17.
 */
public class Around extends UDF {
    // around function for given value
    // based on trianglar Memebrship function with given parameters (peak and margin)

    // rozbić do trapezu

    public Double evaluate(Double val, Double a, Double b, Double c, Double d){
        TrapezoidalTruthFunction truthFunction = new TrapezoidalTruthFunction(a,b,c,d);
        return truthFunction.evaluate(val);
    }
}
