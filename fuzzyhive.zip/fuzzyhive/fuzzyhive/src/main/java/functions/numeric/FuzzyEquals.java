package functions.numeric;

import fuzzy_model.TrapezoidalTruthFunction;
import org.apache.hadoop.hive.ql.exec.UDF;

import static java.lang.StrictMath.max;
import static java.lang.Math.abs;
import static java.lang.StrictMath.min;

/**
 * Created by jadzia on 29.05.17.
 */
public class FuzzyEquals extends UDF {
    public Double evaluate(Double val1, Double m1, Double val2, Double m2){
        //zwracamy wartość funkcji przynależności dla przecięcia
        m1 = abs(m1);
        m2 = abs(m2);
        // funkcje się nie przecinaja
        Double x1 = (val1 * m2 + val2 * m1)/(m1 + m2);
        Double x2 = null;
       // if (m1 == m2)
       //     return x1;

        x2 = (val1 * m2 - val2 * m1)/(m2 - m1);

        // czy wyznaczone wartosci w zakresie
       // if ((x1 < min(val1-m1, val2-m2)) && (x1 > max(val1+m1, val2+m2)))
        if (x1 < val1-m1 || x1 > val1+m1)
            x1 = null;
        if (x2 < val2-m2 || x2 > val2+m2)
        //if ((x2 < min(val1-m1, val2-m2)) && (x2 > max(val1+m1, val2+m2)))
            x2 = null;


        if  (x1 != null)
            return 1 - abs(x1 - val1)/m1;
        else if (x2 != null)
            return 1 - abs(x2 - val1)/m1;
        // both null
        return 0.0;
    }
}
