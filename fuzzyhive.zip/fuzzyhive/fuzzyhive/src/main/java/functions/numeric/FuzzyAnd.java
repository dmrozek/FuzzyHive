package functions.numeric;

import org.apache.hadoop.fs.shell.CommandFormat;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * Created by jadzia on 29.05.17.
 */
public class FuzzyAnd extends UDF {

    /**
     * @param vals array of undefined length of values
     * @return minimum of passed values
     */
    //Udf evaluate - return min
    public Double evaluate(Double... vals){
        if (vals.length < 2) // za mało argumentów
            throw new CommandFormat.NotEnoughArgumentsException(2,vals.length);
        Double min = vals[0];
        for (Double val : vals){
            if (val < min) // and -> min
                min = val;
        }
        return min;
    }
}
