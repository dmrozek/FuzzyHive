import functions.ToUpper;
import functions.numeric.FuzzyAnd;
import junit.framework.Assert;
import org.apache.hadoop.fs.shell.CommandFormat;
import org.apache.hadoop.io.Text;
import org.junit.Test;

/**
 * Created by jadzia on 15.09.17.
 */
public class FuzzyAndTest {
    @Test
    public void evaluate() {
        FuzzyAnd fuzzyAnd = new FuzzyAnd();
        Assert.assertEquals(0.1, fuzzyAnd.evaluate(0.1, 0.2));
    }
    @Test
    public void TwoParameters() {
        FuzzyAnd fuzzyAnd = new FuzzyAnd();
        Assert.assertEquals(0.1, fuzzyAnd.evaluate(0.1, 0.2));
    }

    @Test
    public void threeParameters() {
        FuzzyAnd fuzzyAnd = new FuzzyAnd();
        Assert.assertEquals(0.01, fuzzyAnd.evaluate( 0.1, 0.2, 0.3, 0.01));
    }

    @Test
    public void tenParameters() {
        FuzzyAnd fuzzyAnd = new FuzzyAnd();
        Assert.assertEquals(0.01, fuzzyAnd.evaluate(0.1, 0.2, 0.3,0.4, 0.5, 0.6, 0.01, 0.7, 0.8, 0.9, 1.0));
    }

    @Test(expected = CommandFormat.NotEnoughArgumentsException.class)
    public void oneParameters() {
        FuzzyAnd fuzzyAnd = new FuzzyAnd();
        fuzzyAnd.evaluate(0.1);
    }

    @Test(expected = CommandFormat.NotEnoughArgumentsException.class)
    public void zeroParameters() {
        FuzzyAnd fuzzyAnd = new FuzzyAnd();
        fuzzyAnd.evaluate();
    }
}

