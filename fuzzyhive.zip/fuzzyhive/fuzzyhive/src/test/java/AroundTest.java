import functions.numeric.Around;
import junit.framework.Assert;
import org.junit.Test;

/**
 * Created by jadzia on 19.09.17.
 */
public class AroundTest {

    @Test
    public void theSameValues(){
        Around a = new Around();
        Assert.assertEquals(1.0, a.evaluate(21.0, 19.0, 20.0,22.0, 23.0 ));
    }

    @Test
    public void leftMargin(){
        Around a = new Around();
        Assert.assertEquals(0.6, a.evaluate(19.6, 19.0, 20.0,22.0, 23.0 ),0.0000001);
    }

    @Test
    public void rightMargin(){
        Around a = new Around();
        Assert.assertEquals(0.4, a.evaluate(22.6, 19.0, 20.0,22.0, 23.0 ), 0.0000001);
    }

    @Test
    public void outOfBoundryLeft(){
        Around a = new Around();
        Assert.assertEquals(0.0, a.evaluate(17.0, 19.0, 20.0,22.0, 23.0 ));
    }

    @Test
    public void outOfBoundryRight(){
        Around a = new Around();
        Assert.assertEquals(0.0, a.evaluate(24.0, 19.0, 20.0,22.0, 23.0 ));
    }

    @Test
    public void leftTop(){
        Around a = new Around();
        Assert.assertEquals(1.0, a.evaluate(20.0, 19.0, 20.0,22.0, 23.0 ));
    }

    @Test
    public void rightTop(){
        Around a = new Around();
        Assert.assertEquals(1.0, a.evaluate(22.0, 19.0, 20.0,22.0, 23.0 ));
    }
}
