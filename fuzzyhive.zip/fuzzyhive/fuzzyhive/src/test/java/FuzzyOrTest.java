import functions.numeric.FuzzyOr;

import junit.framework.Assert;
import org.apache.hadoop.fs.shell.CommandFormat;
import org.junit.Test;

/**
 * Created by jadzia on 15.09.17.
 */
public class FuzzyOrTest {

    @Test
    public void TwoParameters(){
        FuzzyOr fuzzyOr = new FuzzyOr();
        Assert.assertEquals(0.2, fuzzyOr.evaluate(0.1,0.2));
    }

    @Test
    public void ThreeParameters(){
        FuzzyOr fuzzyOr = new FuzzyOr();
        Assert.assertEquals(0.2, fuzzyOr.evaluate(0.1,0.2, 0.12));
    }

    @Test(expected = CommandFormat.NotEnoughArgumentsException.class)
    public void OneParameters(){
        FuzzyOr fuzzyOr = new FuzzyOr();
         fuzzyOr.evaluate(0.1);
    }

    @Test(expected = CommandFormat.NotEnoughArgumentsException.class)
    public void ZeroParameters(){
        FuzzyOr fuzzyOr = new FuzzyOr();
         fuzzyOr.evaluate();
    }
}
