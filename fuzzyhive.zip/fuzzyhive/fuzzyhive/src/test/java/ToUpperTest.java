/**
 * Created by jadzia on 04.05.17.
 */
import functions.ToUpper;
import org.apache.hadoop.io.Text;
import junit.framework.Assert;

import org.junit.Test;

public class ToUpperTest {

    @Test
    public void testUDF() {
        ToUpper example = new ToUpper();
        Assert.assertEquals("JADZIA", example.evaluate(new Text("jadzia")).toString());
    }
}