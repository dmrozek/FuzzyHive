import exception.BadNumberOfParamsException;
import exception.UnknownLinguisticTypeException;
import fuzzy_model.GenericMembershipFunction;
import fuzzy_model.TrapezoidalTruthFunction;
import junit.framework.Assert;
import org.junit.Test;


/**
 * Created by jadzia on 11.10.17.
 */
public class GenericMembershipFunctionTest {
    @Test
    public void properArguments(){
        String test = "TrapezoidalTruthFunction/15/20/25/30";
        String[] t = test.split("/");
        GenericMembershipFunction tf = new GenericMembershipFunction();
        try {
            Assert.assertEquals(0.8, tf.evaluate("TrapezoidalTruthFunction/15/20/25/30", 19.0));
        } catch (BadNumberOfParamsException e) {
            e.printStackTrace();
        } catch (UnknownLinguisticTypeException e) {
            e.printStackTrace();
        }
    }
}
