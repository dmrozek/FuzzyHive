import functions.numeric.Around;
import functions.numeric.FuzzyEquals;
import junit.framework.Assert;
import org.junit.Test;

/**
 * Created by jadzia on 19.09.17.
 */
public class FuzzyEqualsTest {

    @Test
    public void theSameValues(){
        FuzzyEquals e = new FuzzyEquals();
        Assert.assertEquals(1.0, e.evaluate(20.0, 1.0, 20.0,1.0));
    }

    @Test
    public void separateValues(){
        FuzzyEquals e = new FuzzyEquals();
        Assert.assertEquals(0.0, e.evaluate(20.0, 1.0, 23.0,1.0));
    }

    @Test
    public void overlapValues(){
        FuzzyEquals e = new FuzzyEquals();
        Assert.assertEquals(0.5, e.evaluate(20.0, 1.0, 21.0,1.0));
    }

    @Test
    public void leftOverlapValues(){
        FuzzyEquals e = new FuzzyEquals();
        Assert.assertEquals(0.5, e.evaluate(20.0, 1.0, 19.0,1.0));
    }

    @Test
    public void innerRange(){
        FuzzyEquals e = new FuzzyEquals();
        Assert.assertEquals(1.0, e.evaluate(20.0, 2.0, 20.0,1.0));
    }

    @Test
    public void overlapRightRange(){
        FuzzyEquals e = new FuzzyEquals();
        Assert.assertEquals(0.666, e.evaluate(18.0, 2.0, 19.0,1.0), 0.001);
    }

    @Test
    public void overlapLeftRange(){
        FuzzyEquals e = new FuzzyEquals();
        Assert.assertEquals(0.666, e.evaluate(17.21,2.0,17.7, 1.0), 0.001);
    }
}
