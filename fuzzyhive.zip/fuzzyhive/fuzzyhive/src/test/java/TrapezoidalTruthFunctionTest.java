import fuzzy_model.TrapezoidalTruthFunction;

import junit.framework.Assert;
import org.junit.Test;

/**
 * Created by jadzia on 19.09.17.
 */
public class TrapezoidalTruthFunctionTest {

    @Test
    public void fullMatch(){
        TrapezoidalTruthFunction tf = new TrapezoidalTruthFunction(19.0,20.0,22.0, 23.0);
        Assert.assertEquals(1.0, tf.evaluate(21.0));
    }
    @Test
    public void leftOutOfRange(){
        TrapezoidalTruthFunction tf = new TrapezoidalTruthFunction(19.0,20.0,22.0, 23.0);
        Assert.assertEquals(0.0, tf.evaluate(18.0));
    }
    @Test
    public void rightOutOfRange(){
        TrapezoidalTruthFunction tf = new TrapezoidalTruthFunction(19.0,20.0,22.0, 23.0);
        Assert.assertEquals(0.0, tf.evaluate(25.0));
    }
    @Test
    public void leftEdge(){
        TrapezoidalTruthFunction tf = new TrapezoidalTruthFunction(19.0,20.0,22.0, 23.0);
        Assert.assertEquals(0.0, tf.evaluate(19.0));
    }
    @Test
    public void rightEdge(){
        TrapezoidalTruthFunction tf = new TrapezoidalTruthFunction(19.0,20.0,22.0, 23.0);
        Assert.assertEquals(0.0, tf.evaluate(23.0));
    }
    @Test
    public void leftTop(){
        TrapezoidalTruthFunction tf = new TrapezoidalTruthFunction(19.0,20.0,22.0, 23.0);
        Assert.assertEquals(1.0, tf.evaluate(20.0));
    }
    @Test
    public void rightTop(){
        TrapezoidalTruthFunction tf = new TrapezoidalTruthFunction(19.0,20.0,22.0, 23.0);
        Assert.assertEquals(1.0, tf.evaluate(22.0));
    }

    @Test
    public void leftSide(){
        TrapezoidalTruthFunction tf = new TrapezoidalTruthFunction(19.0,20.0,22.0, 23.0);
        Assert.assertEquals(0.5, tf.evaluate(19.5));
    }
    @Test
    public void rightSide(){
        TrapezoidalTruthFunction tf = new TrapezoidalTruthFunction(19.0,20.0,22.0, 23.0);
        Assert.assertEquals(0.5, tf.evaluate(22.5));
    }
}
