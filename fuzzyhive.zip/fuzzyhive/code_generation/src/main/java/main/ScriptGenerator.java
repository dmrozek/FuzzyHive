package main;

import java.io.IOException;

/**
 * Created by jadzia on 17.07.17.
 */
public abstract class ScriptGenerator {
    abstract public void generateScript(LinguisticVariablesContainer con, String sourcePath) throws IOException;
}
