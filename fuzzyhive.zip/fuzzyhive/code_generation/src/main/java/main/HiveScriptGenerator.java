package main;

import com.google.common.io.Files;
import java.io.File;
import java.io.IOException;

/**
 * Created by jadzia on 17.07.17.
 */
public class HiveScriptGenerator extends ScriptGenerator {
    public void generateScript(LinguisticVariablesContainer con, String sourcePath) throws IOException {

        File file = new File(sourcePath);

        String content = "";

        for (LinguisticVariable var : con.getLinguisticVariables()){
            for (LinguisticValue val : var.getValues()){
                String scriptLine = "create function " + var.getName()+ "_"+val.getName() + " as " + "\"fuzzy_hive."+var.getName()+"."+val.getName()+"\";\n";
                content += scriptLine;
            }
        }
        Files.write(content.getBytes(), file);
    }
}
