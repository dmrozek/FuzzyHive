package main;

import exception.BadNumberOfParamsException;
import exception.ParamsWrongOrderexception;
import exception.UnknownLinguisticTypeException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/**
 * Created by jadzia on 14.06.17.
 */
public  class LinguistiTypeEvaluator {

     final HashMap<String, Integer> supportedTypes = new HashMap();

    public LinguistiTypeEvaluator() {
        supportedTypes.put("TrapezoidalTruthFunction",4);
    }

    public void evaluate(LinguisticValue val) throws UnknownLinguisticTypeException, BadNumberOfParamsException, ParamsWrongOrderexception {
        Integer numberOfParams = supportedTypes.get(val.getType());
        if (numberOfParams == null) //unknown type
            throw(new UnknownLinguisticTypeException());
        if (numberOfParams != val.getParams().length)
            throw(new BadNumberOfParamsException());

        //type specific evaluation
        if (val.getType() == "TrapezoidalTruthFunction");
            if (!(val.getParams()[0] <= val.getParams()[1] &&
                    val.getParams()[1] <= val.getParams()[2] &&
                    val.getParams()[2] <= val.getParams()[3]
                ))
                throw(new ParamsWrongOrderexception());

    }

    //example: TrapeziodalTruthFunction,1,2,3,4
    public void evaluate(String[] params) throws UnknownLinguisticTypeException, BadNumberOfParamsException {
        for(String s : params){
            s.replaceAll(" ","");
        }

        ArrayList tfParams =new ArrayList(Arrays.asList(params));
        String tfType = tfParams.remove(0).toString();
        Integer numberOfParams = supportedTypes.get(tfType);

        if (numberOfParams == null) //unknown type
            throw(new UnknownLinguisticTypeException());
        if (numberOfParams != tfParams.size())
            throw(new BadNumberOfParamsException());
    }

}
