package main;


import exception.*;

/**
 * Created by jadzia on 14.06.17.
 */
public class LinguisticValue {
    String type;
    Double[] params;
    String name;

    LinguistiTypeEvaluator evaluator = new LinguistiTypeEvaluator();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double[] getParams() {
        return params;
    }

    public void setParams(Double[] params) {
        this.params = params;
    }

    public void evaluate() throws NoNameValueException, NoTypeValue, NoParamsValueException, UnknownLinguisticTypeException, BadNumberOfParamsException, ParamsWrongOrderexception {
        if (name == null)
            throw(new NoNameValueException());
        name = name.substring(0, 1).toUpperCase() + name.substring(1);
        if (type == null )
            throw(new NoTypeValue());
        if (params == null)
            throw(new NoParamsValueException());
        evaluator.evaluate(this);
    }
}
