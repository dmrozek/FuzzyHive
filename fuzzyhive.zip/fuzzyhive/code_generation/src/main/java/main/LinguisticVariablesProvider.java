package main;

import exception.*;

import java.io.FileNotFoundException;

/**
 * Created by jadzia on 14.06.17.
 */
public interface LinguisticVariablesProvider {
    LinguisticVariablesContainer getLingusticVariables(String path) throws NoNameValueException, BadNumberOfParamsException, NoTypeValue, UnknownLinguisticTypeException, NoParamsValueException, NoNameVariableException, ParamsWrongOrderexception, FileNotFoundException;
}
