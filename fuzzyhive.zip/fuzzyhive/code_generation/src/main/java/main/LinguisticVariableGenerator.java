package main;

import main.LinguisticVariablesContainer;

/**
 * Created by jadzia on 15.06.17.
 */
public abstract class LinguisticVariableGenerator {

    protected String sourcePath;

    public LinguisticVariableGenerator(String sourcePath) {
        this.sourcePath = sourcePath;
    }

    public void generateCode(LinguisticVariablesContainer container) {
        for(LinguisticVariable var : container.getLinguisticVariables()) {
            // generate vals
            // generate groupby
            generateValues(var);
            generateGroupBy(var);
        }
    }


    abstract protected void generateValues(LinguisticVariable variable);
    abstract protected void generateGroupBy(LinguisticVariable variable);
}
