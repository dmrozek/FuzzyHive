package main;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import exception.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Type;

import java.util.List;

/**
 * Created by jadzia on 14.06.17.
 */
public class json {
    private static final Type LING_VAR_TYPE = new TypeToken<List<LinguisticVariable>>() {
    }.getType();

    public static void main(String[] args) {

        // Prints "Hello, World" to the terminal window.
        //getClass().getResource("ListStopWords.txt");
        /*Gson g = new Gson();
        try {
            BufferedReader br = new BufferedReader(
                    new FileReader(new File("src/main/resources/file.json").getAbsolutePath()));
            Gson gson = new Gson();
           LinguisticVariablesContainer  con = gson.fromJson(br, LinguisticVariablesContainer.class);


           con.evaluate();
        } catch (Exception e) {
            System.out.print(e.getMessage());
            e.printStackTrace();
        }
    }*/

    }
}