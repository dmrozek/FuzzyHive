package main;

import com.google.gson.Gson;
import exception.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 * Created by jadzia on 14.06.17.
 */
public class JsonLingusticVariablesProvider implements LinguisticVariablesProvider {
    public LinguisticVariablesContainer getLingusticVariables(String path) throws NoNameValueException, BadNumberOfParamsException, NoTypeValue, UnknownLinguisticTypeException, NoParamsValueException, NoNameVariableException, ParamsWrongOrderexception, FileNotFoundException {
        Gson g = new Gson();

            BufferedReader br = new BufferedReader(
                    new FileReader(new File(path)));
            Gson gson = new Gson();
            LinguisticVariablesContainer  con = gson.fromJson(br, LinguisticVariablesContainer.class);


            con.evaluate();
            return con;

    }
}
