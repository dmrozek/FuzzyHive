package main;

import exception.UnknownCodeGenerationType;

/**
 * Created by jadzia on 15.06.17.
 */
public class LinguisticVariableGeneratorFactory {
    String[] supportedTypes = {"Java"};
    public LinguisticVariableGenerator createGeneraotr(String type, String absoluthPath) throws UnknownCodeGenerationType {
        if (type == "Java"){
            return new JavaLinguisticVariablesParser(absoluthPath);
        }
        throw (new UnknownCodeGenerationType(supportedTypes));

    }
}
