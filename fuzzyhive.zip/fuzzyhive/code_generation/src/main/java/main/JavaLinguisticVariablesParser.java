package main;

import net.sourceforge.jenesis4java.*;
import net.sourceforge.jenesis4java.jaloppy.JenesisJalopyEncoder;
import org.apache.hadoop.io.Text;
/**
 * Created by jadzia on 15.06.17.
 */
public class JavaLinguisticVariablesParser extends LinguisticVariableGenerator  {


    public JavaLinguisticVariablesParser(String sourcePath) {
        super(sourcePath);
    }

    public void generateValues(LinguisticVariable var) {

            for (LinguisticValue val : var.getValues()){
                System.setProperty("jenesis.encoder", JenesisJalopyEncoder.class.getName());

                // Get the VirtualMachine implementation.
                VirtualMachine vm = VirtualMachine.getVirtualMachine();

                // Instantiate a new CompilationUnit. The argument to the
                // compilation unit is the "codebase" or directory where the
                // compilation unit should be written.
                //
                // Make a new compilation unit rooted to the given sourcepath.
                CompilationUnit unit = vm.newCompilationUnit(this.sourcePath);
                System.out.print('1');
                // Set the package namespace.
                unit.setNamespace("fuzzy_hive."+var.getName());

                // Add an import statement for fun.
                unit.addImport("fuzzy_model."+val.getType());

                // Comment the package with a javadoc (DocumentationComment).
                unit.setComment(Comment.D, "Auto-Generated using the Jenesis Syntax API");
                System.out.print('2');
                // Make a new class.
                PackageClass cls = unit.newClass(val.getName());

                // Make it a public class.
                cls.setAccess(Access.PUBLIC);
                // Extend Object just for fun.
                cls.setExtends(val.getType());
                // Implement serializable just for fun.
                //cls.addImplements("Serializable");
                // Comment the class with a javadoc (DocumentationComment).
                //unit.setComment(Comment.D, "The HelloWorld example class.");
                Constructor constr = cls.newConstructor();
                constr.setAccess(Access.PUBLIC);
                Invoke invoke = vm.newInvoke("super");
                System.out.print('3');
                for (Double d : val.getParams()){
                    invoke.addArg(d);
                }
                //constr.newStmt(vm.newInvoke("super").addArg(0.0).addArg(0.0).addArg(45.0).addArg(160.0));
                constr.newStmt(invoke);
                // Write the java file.
                unit.encode();
            }

    }

    protected void generateGroupBy(LinguisticVariable var) {
        System.setProperty("jenesis.encoder", JenesisJalopyEncoder.class.getName());

        // Get the VirtualMachine implementation.
        VirtualMachine vm = VirtualMachine.getVirtualMachine();

        // Instantiate a new CompilationUnit. The argument to the
        // compilation unit is the "codebase" or directory where the
        // compilation unit should be written.
        //
        // Make a new compilation unit rooted to the given sourcepath.
        CompilationUnit unit = vm.newCompilationUnit(this.sourcePath);

        // Set the package namespace.
        unit.setNamespace("fuzzy_hive."+var.getName());

        unit.addImport("fuzzy_model.*");
        unit.addImport("org.apache.hadoop.hive.ql.exec.UDF");

        unit.addImport("org.apache.hadoop.io.Text");
        unit.addImport("java.util.Collection");
        unit.addImport("java.util.Collections");
        unit.addImport("java.util.HashMap");
        unit.addImport("java.util.Map");
        unit.addImport("java.util.Iterator");


        PackageClass cls = unit.newClass(var.getName().toString()+"Groups");
        // Make it a public class.
        cls.setAccess(Access.PUBLIC);
        // Extend Object just for fun.
        cls.setExtends("UDF");
        ClassMethod method = cls.newMethod(vm.newType("Text"), "evaluate");
        method.setAccess(Access.PUBLIC);
        method.addParameter(vm.newType("Double"), "val");
        Assign i = vm.newAssign(1, vm.newVar("Map<String, Double> resultMap"), vm.newInvoke("new HashMap<String, Double>"));
        method.newStmt(i);

        for (LinguisticValue val : var.getValues()){
            Invoke in = vm.newInvoke("resultMap.put");
            in.addArg(val.getName()).addArg(vm.newInvoke(vm.newInvoke("new "+val.getName()).toString()+".evaluate").addArg(vm.newVar("val")));
            method.newStmt(in);
       }

        Assign a2 = vm.newAssign(1, vm.newVar("Map.Entry<String, Double> maxEntry"), vm.newNull());
        method.newStmt(a2);
        //For forEx = method.newFor();
        //forEx.addUpdate(vm.newAssign(vm.newVar("i"), vm.newVar("i+1")));
        Assign a3 = vm.newAssign(1, vm.newVar("Iterator it"), vm.newInvoke("resultMap.entrySet().iterator"));
        method.newStmt(a3);
        While exWhile = method.newWhile(vm.newInvoke("it.hasNext"));

        exWhile.newStmt(vm.newAssign(1,vm.newVar("Map.Entry<String, Double> pair"), vm.newInvoke("(Map.Entry)it.next")));
        If ifEx = exWhile.newIf(vm.newVar("maxEntry == null || pair.getValue().compareTo(maxEntry.getValue()) > 0"));
        ifEx.newStmt(vm.newAssign(vm.newVar("maxEntry"), vm.newVar("pair")));

        method.newReturn().setExpression(vm.newVar("new Text(maxEntry.getKey())"));


        // Write the java file.
        unit.encode();



    }
}
