package main;

/**
 * Created by jadzia on 14.06.17.
 */
public class LingusticValueDescription {
    String type;
    Double[] params;
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double[] getParams() {
        return params;
    }

    public void setParams(Double[] params) {
        this.params = params;
    }
}
