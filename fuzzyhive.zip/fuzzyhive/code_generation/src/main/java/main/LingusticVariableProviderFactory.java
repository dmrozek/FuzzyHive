package main;

import exception.UnknownFileType;

/**
 * Created by jadzia on 15.06.17.
 */
public class LingusticVariableProviderFactory {
    String[] supportedTypes = {"JSON"};
    public LinguisticVariablesProvider createProvider(String type) throws UnknownFileType {
        if (type == "JSON")
            return new JsonLingusticVariablesProvider();
        throw (new UnknownFileType(supportedTypes));
    }
}
