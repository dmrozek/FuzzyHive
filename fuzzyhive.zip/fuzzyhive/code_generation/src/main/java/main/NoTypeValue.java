package main;

/**
 * Created by jadzia on 14.06.17.
 */
public class NoTypeValue extends Exception {
    public NoTypeValue() {
    }
}
