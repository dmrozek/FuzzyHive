package main;


import exception.*;

import java.util.ArrayList;

/**
 * Created by jadzia on 14.06.17.
 */
public class LinguisticVariable {
    String name;
    ArrayList<LinguisticValue> values;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<LinguisticValue> getValues() {
        return values;
    }

    public void setValues(ArrayList<LinguisticValue> values) {
        this.values = values;
    }

    public void evaluate() throws NoNameVariableException, NoNameValueException, BadNumberOfParamsException, NoTypeValue, UnknownLinguisticTypeException, NoParamsValueException, ParamsWrongOrderexception {
        if (name == null)
            throw (new NoNameVariableException());
        name = name.toLowerCase();
        for (LinguisticValue val : values){
            val.evaluate();
        }
    }
}
