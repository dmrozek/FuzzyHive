package main;

import exception.*;

import java.util.ArrayList;

/**
 * Created by jadzia on 14.06.17.
 */
public class LinguisticVariablesContainer {
    ArrayList<LinguisticVariable> linguisticVariables;

    public ArrayList<LinguisticVariable> getLinguisticVariables() {
        return linguisticVariables;
    }

    public void setLinguisticVariables(ArrayList<LinguisticVariable> linguisticVariables) {
        this.linguisticVariables = linguisticVariables;
    }

    public void evaluate() throws NoNameVariableException, NoNameValueException, BadNumberOfParamsException, NoTypeValue, UnknownLinguisticTypeException, NoParamsValueException, ParamsWrongOrderexception {
        for (LinguisticVariable var : linguisticVariables) {

            var.evaluate();

        }
    }
}
