import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


import main.*;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.project.MavenProject;

/**
 * @goal code_generation
 * @phase generate-sources
 * @description generate the java source code
 */
public class CodeGenerationMojo extends AbstractMojo {

    /**
     * @parameter expression="project"
     * @required
     */
    protected MavenProject project;

    /**
     * @parameter expression=
     * "project.build.directory/generated-sources/jenesis4java"
     * @required
     */
    protected File outputJavaDirectory;

    /**
     * @parameter expression="paramsFilePath"
     */
    protected String variableDefinitionFilePath;

    LingusticVariableProviderFactory providerFactory =  new LingusticVariableProviderFactory();
    LinguisticVariableGeneratorFactory generatorFactory  = new LinguisticVariableGeneratorFactory();
    ScriptGenerator scriptGenerator = new HiveScriptGenerator();
    public void execute() throws MojoExecutionException, MojoFailureException {
        getLog().info("Hello world :)");
        getLog().info("1");
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();

        if (this.project != null) {
            this.project.addCompileSourceRoot(this.outputJavaDirectory.getAbsolutePath());
        }
        deleteFolder(this.outputJavaDirectory);
        if (!this.outputJavaDirectory.mkdirs()) {
            getLog().error("Could not create source directory!");
        } else {
            try {
                getLog().info("2");
                LinguisticVariablesProvider provider = providerFactory.createProvider("JSON"); //TODO: read type and file location from config
                getLog().info("3");
                LinguisticVariablesContainer container = provider.getLingusticVariables(variableDefinitionFilePath);
                //TODO: generator.genarateCode(container)
                getLog().info("1");
                LinguisticVariableGenerator generator = generatorFactory.createGeneraotr("Java", this.outputJavaDirectory.getAbsolutePath());
                getLog().info("1");
                generator.generateCode(container);
                scriptGenerator.generateScript(container, this.outputJavaDirectory.getAbsolutePath()+"/hiveScript.sql");

               // generateJavaCode();
            } catch (IOException e) {
                throw new MojoExecutionException("Could not generate Java source code!", e);
            }
            catch (Exception e){
                System.out.print(e.getClass().toString());
                System.out.print(e.getMessage());
            }
        }
    }
    public static void deleteFolder(File folder) {
        File[] files = folder.listFiles();
        if(files!=null) { //some JVMs return null for empty dirs
            for(File f: files) {
                if(f.isDirectory()) {
                    deleteFolder(f);
                } else {
                    f.delete();
                }
            }
        }
        folder.delete();
    }
    private void generateJavaCode() throws IOException {
       /* System.setProperty("jenesis.encoder", JenesisJalopyEncoder.class.getName());

        // Get the VirtualMachine implementation.
        VirtualMachine vm = VirtualMachine.getVirtualMachine();

        // Instantiate a new CompilationUnit. The argument to the
        // compilation unit is the "codebase" or directory where the
        // compilation unit should be written.
        //
        // Make a new compilation unit rooted to the given sourcepath.
        CompilationUnit unit = vm.newCompilationUnit(this.outputJavaDirectory.getAbsolutePath());

        // Set the package namespace.
        unit.setNamespace("functions.glucose");

        // Add an import statement for fun.
        unit.addImport("fuzzy_model.TrapezoidalTruthFunction");

        // Comment the package with a javadoc (DocumentationComment).
        unit.setComment(Comment.D, "Auto-Generated using the Jenesis Syntax API");

        // Make a new class.
        PackageClass cls = unit.newClass("Normal");
        // Make it a public class.
        cls.setAccess(Access.PUBLIC);
        // Extend Object just for fun.
        cls.setExtends("TrapezoidalTruthFunction");
        // Implement serializable just for fun.
        //cls.addImplements("Serializable");
        // Comment the class with a javadoc (DocumentationComment).
        unit.setComment(Comment.D, "The HelloWorld example class.");
        Constructor con = cls.newConstructor();
        con.setAccess(Access.PUBLIC);
        con.newStmt(vm.newInvoke("super").addArg(0.0).addArg(0.0).addArg(45.0).addArg(160.0));

        // Make a new Method in the Class having type VOID and name "main".
        //ClassMethod method = cls.newMethod(vm.newType(Type.VOID), "main");
        // Make it a public method.
        //method.setAccess(Access.PUBLIC);
        // Make it a static method
       // method.isStatic(true);
        // Add the "String[] argv" formal parameter.
       // method.addParameter(vm.newArray("String", 1), "argv");

        // Create a new Method Invocation expression.
      //  Invoke println = vm.newInvoke("System.out", "println");

       // if (this.title != null) {
            // Add the Moja parameter string literal as the sole argument.
      //      println.addArg(vm.newString(this.title));
       // } else {
            // Add the Hello World string literal as the sole argument.
       //     println.addArg(vm.newString("Hello World!"));
      //  }
        // Add this expression to the method in a statement.
       // method.newStmt(println);

        // Write the java file.
        unit.encode(); */
    }
}