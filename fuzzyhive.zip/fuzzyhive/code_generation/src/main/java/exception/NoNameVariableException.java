package exception;

/**
 * Created by jadzia on 14.06.17.
 */
public class NoNameVariableException extends Exception {
    public void setDamagedIndex(Integer damagedIndex) {
        this.damagedIndex = damagedIndex;
    }

    Integer damagedIndex;
    String message;
    public NoNameVariableException(int i) {
        damagedIndex = i;
    }

    public NoNameVariableException() {

    }

    public String getMessage(){
        return "Variable at index "+damagedIndex.toString()+" is missing its name.";
    }



}
