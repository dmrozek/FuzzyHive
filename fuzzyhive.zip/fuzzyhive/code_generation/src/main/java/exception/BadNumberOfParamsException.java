package exception;

/**
 * Created by jadzia on 14.06.17.
 */
public class BadNumberOfParamsException extends Exception {
}
