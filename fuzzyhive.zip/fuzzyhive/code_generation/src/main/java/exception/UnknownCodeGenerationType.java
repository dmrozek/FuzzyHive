package exception;

/**
 * Created by jadzia on 15.06.17.
 */
public class UnknownCodeGenerationType extends Exception {
    String message = "Unknown type of code generation";

    public UnknownCodeGenerationType(String[] supportedTypes) {
        String suppTypes = supportedTypes.toString();
      //  message.concat("Supported types are: "+suppTypes);
    }
    public String getMessage(){
        return message;
    }
}
