package exception;

/**
 * Created by jadzia on 15.06.17.
 */
public class UnknownFileType extends Exception {
    String message = "Unknown type of source file";
    public UnknownFileType(String[] supportedTypes) {
        String suppTypes = supportedTypes.toString();
        message.concat("Supported types are: "+suppTypes);
    }
    public String getMessage(){
        return message;
    }
}
