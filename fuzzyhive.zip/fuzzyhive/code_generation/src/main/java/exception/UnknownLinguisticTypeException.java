package exception;

/**
 * Created by jadzia on 14.06.17.
 */
public class UnknownLinguisticTypeException extends Exception {

    String message = "Uknown linguistic value type.";

    public String getMessage(){
        return message;
    }
}
